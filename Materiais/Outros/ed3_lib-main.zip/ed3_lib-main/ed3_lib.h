

/**
*Escrito por Roger em 20/04/2022
*Biblioteca que cont�m algumas fun��es e classeis �teis para as aulas de estruturas de dados 3.
*Tem fun��o de timestamp, fun��o de gera��o de n�meros aleat�rios, e fun��o para preenxer um vetor com n�meros aleatoriamente.
*Tamb�m tem uma classe para depurar o tempo de dura��o de uma fun��o.
*Bom proveito!
**/

#ifndef ED3_LIB_H
#define ED3_LIB_H

#include<iostream>
#include<stdlib.h>
#include<algorithm>
#include<string>
#include<chrono>
#include<stdint.h>
#include<random>
#include<vector>


//Costume pessoal, isso...
typedef int8_t int8;
typedef uint8_t uint8;
typedef int16_t int16;
typedef uint16_t uint16;
typedef int32_t int32;
typedef uint32_t uint32;
typedef int64_t int64;
typedef uint64_t uint64;

//Recuperar o tempo em millisegundos desde 01/01/1970...
int64 gettimestamp();
//Retorna um n�mero aleat�rio entre min_val e max_val...
int32 random_int32(int32 min_val, int32 max_val);
//Preenxe um vector com a quantidade especificada de itens...
void fill_vector(std::vector<int32>& vect, uint32 size, int32 min_val=0, int32 max_val=100);
//Sobrecarga para printar um std::vector...
std::ostream& operator<<(std::ostream& os, const std::vector<int32>& vect);



/**
*Classe para cronometrar a dura��o de uma determinada fun��o.
*Basta instanciar passando como par�metro algum nome que queira para identificar, ou passar a macro __FUNCTION__.
*Ela printa no construtor quando entrou na fun��o, e no destruidor antes da fun��o sair mostrando o tempo que ficou ativa.
**/
class FuncTimer
{
public:
std::string func_name;//Nome da fun��o...
int64 start;//Timestamp, em millisegundos de quando instanciou a classe...
FuncTimer(const std::string& func_name);
~FuncTimer();
};
#endif

#ifndef ED3_LIB_IMPLEMENTATION
#define ED3_LIB_IMPLEMENTATION

//Retorna a quantidade de millisegundos desde 01/01/1970
int64 gettimestamp()
{
std::chrono::system_clock::time_point tp=std::chrono::system_clock::now();
std::chrono::system_clock::duration dtn=tp.time_since_epoch();
return std::chrono::duration_cast<std::chrono::milliseconds>(dtn).count();
}

int32 random_int32(int32 min_val, int32 max_val)
{
  unsigned seed =static_cast<unsigned>(std::chrono::system_clock::now().time_since_epoch().count());
std::default_random_engine generator (seed);
std::uniform_int_distribution<int32> distribution(min_val, max_val);
return distribution(generator);
}

void fill_vector(std::vector<int32>& vect, uint32 size, int32 min_val, int32 max_val)
{
vect.resize(0);
vect.reserve(size+1);
for(uint32 i=0; i<size; i++)
{
vect.push_back(random_int32(min_val, max_val));
}
}


std::ostream& operator<<(std::ostream& os, const std::vector<int32>& vect)
{
std::cout<<"Mostrando vector com "<<vect.size()<<" elementos..."<<std::endl;
for(auto it=vect.begin(); it!=vect.end(); ++it)
{
std::cout<<(*it)<<std::endl;
}
return os;
}

//Classe de cronometra��o...
FuncTimer::FuncTimer(const std::string& func_name)
{
this->func_name=func_name;
std::cout<<"Entrando na fun��o: "<<func_name<<std::endl;
start=gettimestamp();
}

//"Evitar a fadiga..."
FuncTimer::~FuncTimer()
{
int64 end=gettimestamp();
std::cout<<"A fun��o "<<this->func_name<<" levou "<<(end-start)<<" ms para ser conclu�da."<<std::endl;
}
#endif
